// Removido "1.jpg" para evitar errores de carga en la primera iteración
const images = [
  "1.jpeg",
  "2.jpeg",
  "3.jpeg",
  "4.jpeg"
];

const slider = document.getElementById("slider");
const nextBtn = document.getElementById("next");
const prevBtn = document.getElementById("prev");

let current = 0;

function showImage(index){
    slider.style.opacity = 0;
    setTimeout(() => {
        slider.src = images[index];
        slider.style.opacity = 1;
    }, 300);
}

nextBtn.addEventListener("click", () => {
    current++;
    if(current >= images.length){
        current = 0;
    }
    showImage(current);
});

prevBtn.addEventListener("click", () => {
    current--;
    if(current < 0){
        current = images.length - 1;
    }
    showImage(current);
});

/* Autoplay cada 5 segundos */
setInterval(() => {
    current++;
    if(current >= images.length){
        current = 0;
    }
    showImage(current);
}, 5000);

/* Swipe móvil (Deslizar con el dedo) */
let touchStartX = 0;
let touchEndX = 0;

slider.addEventListener("touchstart", (e) => {
    touchStartX = e.changedTouches[0].screenX;
});

slider.addEventListener("touchend", (e) => {
    touchEndX = e.changedTouches[0].screenX;

    if(touchEndX < touchStartX - 50){
        current++;
        if(current >= images.length){
            current = 0;
        }
        showImage(current);
    }

    if(touchEndX > touchStartX + 50){
        current--;
        if(current < 0){
            current = images.length - 1;
        }
        showImage(current);
    }
});